﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace VideoConverterr
{
    public partial class MainForm : Form
    {
        private string inputFile;
        private string ffmpegPath;
        private Process currentProcess;
        private CancellationTokenSource cts;
        private bool isConverting = false;

        public MainForm()
        {
            InitializeComponent();
            // Определяем путь к ffmpeg.exe в подпапке ffmpeg
            ffmpegPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ffmpeg", "ffmpeg.exe");
        }

        private void btnSelectVideo_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Video Files|*.mp4;*.avi;*.mkv;*.webm;*.mov;*.wmv;*.flv;*.3gp|All Files|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    inputFile = ofd.FileName;
                    lblFileName.Text = Path.GetFileName(inputFile);
                }
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Заполняем выпадающий список форматами, добавляем MP4
            cmbFormat.Items.AddRange(new object[] { "GIF", "MP3", "AVI", "MKV", "WEBM", "MP4" });
            cmbFormat.SelectedIndex = 0;
        }

        private async void btnConvert_Click(object sender, EventArgs e)
        {
            if (isConverting) return;

            if (string.IsNullOrEmpty(inputFile))
            {
                MessageBox.Show("Сначала выберите видео!");
                return;
            }

            if (cmbFormat.SelectedItem == null)
            {
                MessageBox.Show("Выберите формат для конвертации!");
                return;
            }

            if (!File.Exists(ffmpegPath))
            {
                MessageBox.Show("FFmpeg не найден! Убедитесь, что он находится в папке ffmpeg рядом с программой.");
                return;
            }

            // Устанавливаем флаг конвертации
            isConverting = true;

            // Блокируем кнопки и показываем прогресс
            btnConvert.Enabled = false;
            btnSelectVideo.Enabled = false;
            cmbFormat.Enabled = false;
            progressBar.Visible = true;
            btnCancel.Visible = true;

            string outputFormat = cmbFormat.SelectedItem.ToString();
            string outputFile = Path.Combine(
                Path.GetDirectoryName(inputFile),
                "VideoConverted." + outputFormat.ToLower()
            );

            // Формируем аргументы для FFmpeg в зависимости от формата
            string arguments = $"-i \"{inputFile}\"";

            // Добавляем специфические параметры для разных форматов
            switch (outputFormat.ToUpper())
            {
                case "GIF":
                    arguments += " -vf \"fps=10,scale=320:-1:flags=lanczos\" -c:v gif";
                    break;
                case "MP3":
                    arguments += " -q:a 0 -map a";
                    break;
                case "WEBM":
                    arguments += " -c:v libvpx -crf 10 -b:v 1M -c:a libvorbis";
                    break;
                case "MP4":
                    arguments += " -c:v libx264 -preset medium -crf 23 -c:a aac -b:a 128k";
                    break;
            }

            arguments += $" \"{outputFile}\"";

            // Создаем токен отмены
            cts = new CancellationTokenSource();

            // Запускаем процесс конвертации асинхронно
            bool success = false;
            string errorMessage = "";

            try
            {
                await Task.Run(() =>
                {
                    ProcessStartInfo psi = new ProcessStartInfo
                    {
                        FileName = ffmpegPath,
                        Arguments = arguments,
                        UseShellExecute = false,
                        CreateNoWindow = true,
                        RedirectStandardError = true
                    };

                    using (currentProcess = new Process())
                    {
                        currentProcess.StartInfo = psi;

                        // Обработка вывода ошибок
                        currentProcess.ErrorDataReceived += (s, evt) =>
                        {
                            if (!string.IsNullOrEmpty(evt.Data))
                            {
                                Debug.WriteLine(evt.Data);
                            }
                        };

                        currentProcess.Start();
                        currentProcess.BeginErrorReadLine();

                        // Ожидание завершения с проверкой отмены
                        while (!currentProcess.WaitForExit(100))
                        {
                            if (cts.Token.IsCancellationRequested)
                            {
                                currentProcess.Kill();
                                throw new OperationCanceledException("Конвертация отменена пользователем");
                            }
                        }

                        success = currentProcess.ExitCode == 0;
                    }
                }, cts.Token);
            }
            catch (OperationCanceledException)
            {
                errorMessage = "Конвертация отменена";
                success = false;

                // Удаляем частично сконвертированный файл
                if (File.Exists(outputFile))
                {
                    try { File.Delete(outputFile); } catch { }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                success = false;
            }
            finally
            {
                currentProcess = null;
                cts?.Dispose();
                cts = null;
                isConverting = false;
            }

            // Восстанавливаем интерфейс
            if (!this.IsDisposed)
            {
                this.Invoke(new Action(() =>
                {
                    progressBar.Visible = false;
                    btnConvert.Enabled = true;
                    btnSelectVideo.Enabled = true;
                    cmbFormat.Enabled = true;
                    btnCancel.Visible = false;

                    if (success)
                    {
                        MessageBox.Show($"Конвертация завершена!\nФайл сохранен как: {outputFile}");
                    }
                    else if (!string.IsNullOrEmpty(errorMessage))
                    {
                        MessageBox.Show($"Ошибка при конвертации: {errorMessage}");
                    }
                }));
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (cts != null && !cts.IsCancellationRequested)
            {
                cts.Cancel();
            }
        }

        // Завершаем все процессы при закрытии приложения
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Если идет конвертация, спрашиваем подтверждение
            if (isConverting)
            {
                var result = MessageBox.Show("Конвертация все еще выполняется. Вы уверены, что хотите выйти?",
                                           "Подтверждение выхода",
                                           MessageBoxButtons.YesNo,
                                           MessageBoxIcon.Warning);

                if (result == DialogResult.No)
                {
                    e.Cancel = true;
                    return;
                }
            }

            // Завершаем все процессы FFmpeg
            KillFFmpegProcesses();
        }

        // Метод для завершения всех процессов FFmpeg
        private void KillFFmpegProcesses()
        {
            try
            {
                // Завершаем текущий процесс, если он запущен
                if (currentProcess != null && !currentProcess.HasExited)
                {
                    currentProcess.Kill();
                    currentProcess.WaitForExit(1000);
                }

                // Завершаем все другие процессы ffmpeg, которые могли остаться
                var processes = Process.GetProcessesByName("ffmpeg");
                foreach (var process in processes)
                {
                    try
                    {
                        process.Kill();
                        process.WaitForExit(1000);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"Ошибка при завершении процесса ffmpeg: {ex.Message}");
                    }
                }                            
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Ошибка при завершении процессов: {ex.Message}");
            }
        }

        // Дополнительная защита - завершение процессов при уничтожении формы
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            base.OnFormClosed(e);
            KillFFmpegProcesses();
        }
    }
}